﻿# Earney IT Support App Monitoring Script
# This script checks if the Support App is installed and running properly
# Exit Code 0 = Success (installed and running)
# Exit Code 1 = Error (not installed or not running)

$AppName = "Earney IT Support"
$ExeName = "EarneyITSupport.exe"
$InstallDir = "$env:ProgramFiles\EarneyIT\Support"
$ExePath = Join-Path $InstallDir $ExeName

# Check if application is installed
$installed = $false
$version = $null

# Check registry for installation
$regPath = "HKLM:\SOFTWARE\EarneyIT\Support"
if (Test-Path $regPath) {
    $installed = $true
    $version = (Get-ItemProperty -Path $regPath -Name "Version" -ErrorAction SilentlyContinue).Version
    $installPath = (Get-ItemProperty -Path $regPath -Name "InstallPath" -ErrorAction SilentlyContinue).InstallPath
}

# Also check if exe exists
$exeExists = Test-Path $ExePath

if (-not $installed -and -not $exeExists) {
    Write-Host "<-Start Result->"
    Write-Host "ERROR: $AppName is not installed"
    Write-Host "<-End Result->"
    exit 1
}

if (-not $exeExists) {
    Write-Host "<-Start Result->"
    Write-Host "ERROR: $AppName registry entry exists but executable not found at $ExePath"
    Write-Host "<-End Result->"
    exit 1
}

# Get version from exe if not in registry
if (-not $version) {
    $version = (Get-Item $ExePath).VersionInfo.FileVersion
}

# Check if startup entry exists
$startupEntry = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name $AppName -ErrorAction SilentlyContinue

if (-not $startupEntry) {
    Write-Host "<-Start Result->"
    Write-Host "WARNING: $AppName is installed but startup entry is missing"
    Write-Host "<-End Result->"
    exit 1
}

# Check if process is running (for any user)
$process = Get-Process -Name "EarneyITSupport" -ErrorAction SilentlyContinue

if (-not $process) {
    # Process not running - this may be OK if no user is logged in
    # Check if any interactive users are logged in
    $loggedInUsers = query user 2>$null | Select-Object -Skip 1
    
    if ($loggedInUsers) {
        Write-Host "<-Start Result->"
        Write-Host "WARNING: $AppName is installed (Version: $version) but not running. Users are logged in."
        Write-Host "<-End Result->"
        exit 1
    } else {
        # No users logged in, so app not running is expected
        Write-Host "<-Start Result->"
        Write-Host "OK: $AppName installed (Version: $version), not running (no users logged in)"
        Write-Host "<-End Result->"
        exit 0
    }
}

# All checks passed
Write-Host "<-Start Result->"
Write-Host "OK: $AppName installed (Version: $version) and running"
Write-Host "<-End Result->"
exit 0
