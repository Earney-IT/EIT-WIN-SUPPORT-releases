@echo off
REM One-click uninstaller for Earney IT Support App.
REM Self-elevates to admin and runs UninstallSupportAgent.ps1.

setlocal
set "SCRIPT_DIR=%~dp0"

net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

echo Uninstalling Earney IT Support App...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%UninstallSupportAgent.ps1"
set "RC=%ERRORLEVEL%"

if %RC% NEQ 0 (
    echo.
    echo Uninstall FAILED with exit code %RC%.
    pause
    exit /b %RC%
)

echo.
echo Uninstall complete.
timeout /t 3 >nul
exit /b 0
