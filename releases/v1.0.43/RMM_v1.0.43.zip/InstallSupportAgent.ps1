﻿<#
.SYNOPSIS
    Installs Earney IT Support App for all users on the system.

.DESCRIPTION
    Copies EarneyITSupport.exe to Program Files, creates shortcuts, configures
    startup for all users, and registers in Add/Remove Programs.

    Designed to be safe to re-run (idempotent upgrade). When the installed
    version is equal or newer than the source, no action is taken unless
    -Force is supplied.

.PARAMETER Silent
    Suppress all console output. Errors still write to Event Log and return
    a non-zero exit code.

.PARAMETER NoLaunch
    Do not launch the app for currently logged-in users after install.
    Useful for upgrades or scheduled maintenance windows.

.PARAMETER Force
    Reinstall even if the installed version is the same or newer.

.PARAMETER LogPath
    Optional file path for installation logs. Logs always go to the Event Log;
    this writes a copy to a file as well.

.PARAMETER WebhookSecret
    Per-tenant secret used by the app to sign ticket-submission requests with
    HMAC-SHA256. Persisted to HKLM\SOFTWARE\EarneyIT\Support\WebhookSecret.
    When deploying via Datto RMM, pass $env:EIT_WEBHOOK_SECRET (which Datto
    populates from the site variable of the same name).
    If omitted, any existing secret in the registry is preserved.

.NOTES
    Requires: Administrator privileges
    Author: Earney IT

    Exit Codes:
        0  - Success (installed, upgraded, or already up-to-date)
        1  - Generic failure
        2  - Source executable missing
        3  - Already installed at same/newer version (only when -Force not set)
             Note: this is reported but still returns 0 unless changed.
#>

#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$NoLaunch,
    [switch]$Force,
    [string]$LogPath,
    [string]$WebhookSecret
)

$ErrorActionPreference = "Stop"

# ---- Configuration ----
$AppName     = "Earney IT Support"
$ExeName     = "EarneyITSupport.exe"
$Publisher   = "Earney IT"
$InstallDir  = Join-Path $env:ProgramFiles "EarneyIT\Support"
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceExe   = Join-Path $ScriptDir $ExeName

# ---- Logging ----
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$timestamp] [$Level] $Message"

    if (-not $Silent) { Write-Host $line }

    if ($LogPath) {
        try { Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue } catch {}
    }

    try {
        if (-not [System.Diagnostics.EventLog]::SourceExists("EarneyIT")) {
            New-EventLog -LogName Application -Source "EarneyIT" -ErrorAction SilentlyContinue
        }
        $entryType = switch ($Level) {
            "ERROR"   { "Error" }
            "WARNING" { "Warning" }
            default   { "Information" }
        }
        Write-EventLog -LogName Application -Source "EarneyIT" -EventId 1000 `
            -EntryType $entryType -Message $Message -ErrorAction SilentlyContinue
    } catch { }
}

# ---- Version helpers ----
function Get-InstalledVersion {
    $regPath = "HKLM:\SOFTWARE\EarneyIT\Support"
    if (Test-Path $regPath) {
        $v = (Get-ItemProperty -Path $regPath -Name "Version" -ErrorAction SilentlyContinue).Version
        if ($v) { return $v }
    }
    $exePath = Join-Path $InstallDir $ExeName
    if (Test-Path $exePath) {
        return (Get-Item $exePath).VersionInfo.FileVersion
    }
    return $null
}

function Compare-Versions([string]$a, [string]$b) {
    # Returns 1 if $a > $b, 0 if equal, -1 if a < b
    try {
        $va = [System.Version]::new($a)
        $vb = [System.Version]::new($b)
        return $va.CompareTo($vb)
    } catch {
        return 0
    }
}

try {
    Write-Log "Starting installation of $AppName"

    if (-not (Test-Path $SourceExe)) {
        Write-Log "Source file not found: $SourceExe" -Level "ERROR"
        exit 2
    }

    $newVersion = (Get-Item $SourceExe).VersionInfo.FileVersion
    $installedVersion = Get-InstalledVersion
    $isUpgrade = $false

    if ($installedVersion) {
        Write-Log "Detected existing install version: $installedVersion (new: $newVersion)"
        $cmp = Compare-Versions $newVersion $installedVersion
        if ($cmp -le 0 -and -not $Force) {
            Write-Log "Installed version is the same or newer. Use -Force to reinstall. Exiting."
            exit 0
        }
        $isUpgrade = $true
    } else {
        Write-Log "Performing fresh install (version $newVersion)"
    }

    # Kill any running instances (always — required before overwriting exe)
    $runningProcesses = Get-Process -Name "EarneyITSupport" -ErrorAction SilentlyContinue
    if ($runningProcesses) {
        Write-Log "Stopping running instances..."
        $runningProcesses | Stop-Process -Force
        Start-Sleep -Seconds 2
    }

    if (-not (Test-Path $InstallDir)) {
        Write-Log "Creating installation directory: $InstallDir"
        New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    }

    $destExe = Join-Path $InstallDir $ExeName
    Write-Log "Copying $ExeName to $InstallDir"
    Copy-Item -Path $SourceExe -Destination $destExe -Force

    # Copy the SPA bundle alongside the exe. WebUiHost.cs maps
    # SetVirtualHostNameToFolderMapping("eit.local",
    # Path.Combine(<exe-dir>, "webui"), ...) so the bundle MUST live next
    # to the exe or the WebView2 renders the fallback "missing folder"
    # page. Before this fix the installer shipped only the exe and the
    # SPA stayed frozen at whatever version was on disk from the first
    # install — silently masking every UI change since deploy.
    $SourceWebui = Join-Path $ScriptDir "webui"
    $destWebui   = Join-Path $InstallDir "webui"
    if (Test-Path $SourceWebui) {
        Write-Log "Copying webui bundle to $destWebui"
        if (Test-Path $destWebui) {
            # Wipe the target first so old asset-hash files (which the new
            # build no longer references) don't linger and confuse browser
            # caches. Quick — the bundle is ~500KB.
            Remove-Item -Path $destWebui -Recurse -Force
        }
        Copy-Item -Path $SourceWebui -Destination $destWebui -Recurse -Force
    } else {
        Write-Log "WARNING: webui bundle not found at $SourceWebui — SPA will fall back to the missing-folder page." -Level "WARNING"
    }

    # ---- Shortcuts ----
    $WshShell = New-Object -ComObject WScript.Shell

    $startMenuPath = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Earney IT"
    if (-not (Test-Path $startMenuPath)) {
        Write-Log "Creating Start Menu folder: $startMenuPath"
        New-Item -ItemType Directory -Path $startMenuPath -Force | Out-Null
    }

    function New-Shortcut($path, $target, $args, $description) {
        $s = $WshShell.CreateShortcut($path)
        $s.TargetPath = $target
        if ($args) { $s.Arguments = $args }
        $s.WorkingDirectory = Split-Path $target -Parent
        $s.IconLocation = "$target,0"
        $s.Description = $description
        $s.Save()
    }

    $mainShortcut    = Join-Path $startMenuPath "$AppName.lnk"
    $newTicketLnk    = Join-Path $startMenuPath "New Support Request.lnk"
    $desktopShortcut = Join-Path $env:PUBLIC "Desktop\New Support Request.lnk"

    New-Shortcut $mainShortcut    $destExe $null     "Submit support tickets to Earney IT"
    New-Shortcut $newTicketLnk    $destExe "/ticket" "Open a new Earney IT support ticket"
    New-Shortcut $desktopShortcut $destExe "/ticket" "Open a new Earney IT support ticket"

    # ---- AppUserModelID (Win10+ toast notifications) ---------------------
    #
    # Modern toast notifications require the launching .exe to be associated
    # with a stable AUMID. Windows learns the AUMID from a Start Menu
    # shortcut that has the System.AppUserModel.ID property set. Without
    # this, ToastNotificationManager.CreateToastNotifier silently swallows
    # the toast and the app falls back to legacy NotifyIcon balloons.
    #
    # AUMID string here MUST match ToastConfig.AppUserModelId in
    # EarneyITSupportTray.cs.
    # ---------------------------------------------------------------------
    $aumid = "EarneyIT.Support.Tray"
    $aumidHelperType = @'
using System;
using System.Runtime.InteropServices;
namespace EarneyITSupport {
    [StructLayout(LayoutKind.Sequential)]
    public struct PropertyKey {
        public Guid fmtid;
        public uint pid;
    }
    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IPropertyStore {
        [PreserveSig] int GetCount(out uint cProps);
        [PreserveSig] int GetAt(uint iProp, out PropertyKey pkey);
        [PreserveSig] int GetValue(ref PropertyKey key, [Out] PropVariant pv);
        [PreserveSig] int SetValue(ref PropertyKey key, PropVariant pv);
        [PreserveSig] int Commit();
    }
    [StructLayout(LayoutKind.Sequential)]
    public sealed class PropVariant : IDisposable {
        public ushort vt;
        public ushort wReserved1;
        public ushort wReserved2;
        public ushort wReserved3;
        public IntPtr p;
        public int p2;
        public PropVariant() { vt = 0; }
        public PropVariant(string s) {
            vt = 31; // VT_LPWSTR
            p = Marshal.StringToCoTaskMemUni(s);
        }
        public void Dispose() {
            if (p != IntPtr.Zero) { Marshal.FreeCoTaskMem(p); p = IntPtr.Zero; }
            vt = 0;
            GC.SuppressFinalize(this);
        }
        ~PropVariant() { Dispose(); }
    }
    public static class Shell {
        // SHGetPropertyStoreFromParsingName takes the requested interface as the
        // 4th arg and returns it via an [out] void**. The whole IPropertyStore
        // dance must stay inside compiled C# — PowerShell's COM wrapper hides
        // non-IDispatch interface methods and downgrades the object to a bare
        // __ComObject with no callable SetValue/Commit.
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
        private static extern void SHGetPropertyStoreFromParsingName(
            [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
            IntPtr pbc,
            int flags,
            [In] ref Guid riid,
            [Out, MarshalAs(UnmanagedType.Interface)] out IPropertyStore ppv);

        public static void SetShortcutAumid(string shortcutPath, string aumid) {
            Guid iid = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");
            IPropertyStore store;
            SHGetPropertyStoreFromParsingName(shortcutPath, IntPtr.Zero, 2, ref iid, out store);
            try {
                PropertyKey pkey = new PropertyKey {
                    fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"),
                    pid = 5
                };
                PropVariant pv = new PropVariant(aumid);
                try {
                    int hr = store.SetValue(ref pkey, pv);
                    if (hr != 0) throw new System.ComponentModel.Win32Exception(hr, "IPropertyStore.SetValue failed");
                    hr = store.Commit();
                    if (hr != 0) throw new System.ComponentModel.Win32Exception(hr, "IPropertyStore.Commit failed");
                } finally { pv.Dispose(); }
            } finally { Marshal.ReleaseComObject(store); }
        }
    }
}
'@
    if (-not ('EarneyITSupport.Shell' -as [type])) {
        Add-Type -TypeDefinition $aumidHelperType -ErrorAction Stop | Out-Null
    }

    foreach ($lnk in @($mainShortcut, $newTicketLnk)) {
        try {
            [EarneyITSupport.Shell]::SetShortcutAumid($lnk, $aumid)
            Write-Log "Set AUMID '$aumid' on $lnk"
        } catch {
            Write-Log "Failed to set AUMID on ${lnk}: $_" -Level "WARNING"
        }
    }

    # ---- URL protocol handler (eitsupport://) ---------------------------
    #
    # Toast-action buttons use activationType="protocol" with eitsupport://
    # URLs. The shell looks here to find the launcher. We register the
    # existing tray .exe; it parses the URL out of its single command-line
    # arg, hands off to the running instance via WM_TOAST_ACTION, and exits.
    # ---------------------------------------------------------------------
    $urlSchemeKey = "HKLM:\SOFTWARE\Classes\eitsupport"
    if (-not (Test-Path $urlSchemeKey)) { New-Item -Path $urlSchemeKey -Force | Out-Null }
    Set-ItemProperty -Path $urlSchemeKey -Name "(default)"     -Value "URL:Earney IT Support" -Type String
    Set-ItemProperty -Path $urlSchemeKey -Name "URL Protocol"  -Value ""                      -Type String
    if (-not (Test-Path "$urlSchemeKey\DefaultIcon")) { New-Item -Path "$urlSchemeKey\DefaultIcon" -Force | Out-Null }
    Set-ItemProperty -Path "$urlSchemeKey\DefaultIcon" -Name "(default)" -Value "$destExe,0" -Type String
    if (-not (Test-Path "$urlSchemeKey\shell\open\command")) { New-Item -Path "$urlSchemeKey\shell\open\command" -Force | Out-Null }
    Set-ItemProperty -Path "$urlSchemeKey\shell\open\command" -Name "(default)" -Value "`"$destExe`" `"%1`"" -Type String
    Write-Log "Registered URL protocol: eitsupport:// → $destExe"

    # ---- Registry: startup ----
    $runKeyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    Write-Log "Configuring startup entry in registry"
    Set-ItemProperty -Path $runKeyPath -Name $AppName -Value "`"$destExe`"" -Type String

    # ---- Registry: Add/Remove Programs ----
    $uninstallKeyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EarneyITSupport"
    if (-not (Test-Path $uninstallKeyPath)) {
        New-Item -Path $uninstallKeyPath -Force | Out-Null
    }

    $uninstallScript = Join-Path $InstallDir "Uninstall.ps1"

    Set-ItemProperty -Path $uninstallKeyPath -Name "DisplayName"     -Value $AppName     -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "DisplayVersion"  -Value $newVersion  -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "Publisher"       -Value $Publisher   -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "InstallLocation" -Value $InstallDir  -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "InstallDate"     -Value (Get-Date -Format "yyyyMMdd") -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "DisplayIcon"     -Value $destExe     -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$uninstallScript`"" -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "QuietUninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$uninstallScript`" -Silent" -Type String
    Set-ItemProperty -Path $uninstallKeyPath -Name "NoModify"        -Value 1 -Type DWord
    Set-ItemProperty -Path $uninstallKeyPath -Name "NoRepair"        -Value 1 -Type DWord

    # ---- Registry: app settings ----
    $appRegPath = "HKLM:\SOFTWARE\EarneyIT\Support"
    if (-not (Test-Path $appRegPath)) {
        New-Item -Path $appRegPath -Force | Out-Null
    }
    Set-ItemProperty -Path $appRegPath -Name "InstallPath" -Value $InstallDir -Type String
    Set-ItemProperty -Path $appRegPath -Name "Version"     -Value $newVersion -Type String
    Set-ItemProperty -Path $appRegPath -Name "InstallDate" -Value (Get-Date -Format "yyyy-MM-dd HH:mm:ss") -Type String

    # Persist the per-tenant webhook secret if provided. The app reads this at
    # submission time to HMAC-sign requests; without it, ticket submission
    # surfaces a "device not provisioned" error.
    if ($WebhookSecret) {
        Set-ItemProperty -Path $appRegPath -Name "WebhookSecret" -Value $WebhookSecret -Type String
        Write-Log "Stored WebhookSecret (length=$($WebhookSecret.Length))"
    } else {
        $existing = (Get-ItemProperty -Path $appRegPath -Name "WebhookSecret" -ErrorAction SilentlyContinue).WebhookSecret
        if ($existing) {
            Write-Log "Preserving existing WebhookSecret in registry"
        } else {
            Write-Log "No WebhookSecret provided and none on file — ticket submission will fail until provisioned" -Level "WARNING"
        }
    }

    # ---- Uninstall script ----
    Write-Log "Writing uninstall script: $uninstallScript"
    $uninstallContent = @'
#Requires -RunAsAdministrator
[CmdletBinding()]
param([switch]$Silent)

$ErrorActionPreference = "SilentlyContinue"

$AppName    = "Earney IT Support"
$InstallDir = "$env:ProgramFiles\EarneyIT\Support"

function Say($msg) { if (-not $Silent) { Write-Host $msg } }

Say "Uninstalling $AppName..."

Get-Process -Name "EarneyITSupport" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name $AppName -ErrorAction SilentlyContinue
Remove-Item "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Earney IT" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:PUBLIC\Desktop\New Support Request.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EarneyITSupport" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "HKLM:\SOFTWARE\EarneyIT\Support" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "HKLM:\SOFTWARE\Classes\eitsupport" -Recurse -Force -ErrorAction SilentlyContinue

# Schedule delayed delete of install dir so this script can finish
Start-Process -FilePath "cmd.exe" -ArgumentList "/c timeout /t 3 >nul & rd /s /q `"$InstallDir`"" -WindowStyle Hidden

Say "$AppName has been uninstalled."
exit 0
'@
    $uninstallContent | Out-File -FilePath $uninstallScript -Encoding UTF8 -Force

    Write-Log "Installation completed successfully (version $newVersion)"

    # ---- Launch app for logged-in users ----
    if ($NoLaunch) {
        Write-Log "Skipping app launch (-NoLaunch specified)"
    } elseif ($isUpgrade) {
        Write-Log "Skipping app launch (this is an upgrade — app will start on next login)"
    } else {
        Write-Log "Starting application for logged-in users..."
        $explorerProcesses = Get-WmiObject Win32_Process -Filter "Name='explorer.exe'" -ErrorAction SilentlyContinue
        foreach ($proc in $explorerProcesses) {
            $owner = $proc.GetOwner()
            if ($owner.ReturnValue -eq 0) {
                $userId = "$($owner.Domain)\$($owner.User)"
                Write-Log "Launching app for user: $userId"

                $taskName = "EarneyITSupport_StartOnce_$($owner.User)"
                try {
                    $action    = New-ScheduledTaskAction -Execute $destExe
                    $principal = New-ScheduledTaskPrincipal -UserId $userId -LogonType Interactive
                    $settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
                    Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Force | Out-Null
                    Start-ScheduledTask -TaskName $taskName
                    Start-Sleep -Seconds 2
                    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
                } catch {
                    Write-Log "Failed to launch app for ${userId}: $_" -Level "WARNING"
                }
            }
        }
    }

    exit 0

} catch {
    Write-Log "Installation failed: $_" -Level "ERROR"
    exit 1
}
