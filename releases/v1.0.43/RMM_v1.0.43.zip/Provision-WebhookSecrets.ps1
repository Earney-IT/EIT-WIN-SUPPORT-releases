﻿<#
.SYNOPSIS
    Provision per-site webhook signing secrets for the EarneyIT Support app.

.DESCRIPTION
    For each Datto RMM site (filtered or all), this script:

      1. Generates a fresh 32-byte random secret (or reuses an existing one if
         -Rotate is not specified).
      2. Upserts the secret into the n8n 'EIT App Webhook Secrets' data table
         keyed by Datto siteUid.
      3. Pushes the secret as a Datto site variable named EIT_WEBHOOK_SECRET so
         the install component can read it via $env:EIT_WEBHOOK_SECRET and
         persist it to HKLM\SOFTWARE\EarneyIT\Support\WebhookSecret.

    Run this once per site before deploying v1.0.36+ of the tray app. Re-run
    with -Rotate to force a fresh secret on all matched sites.

.PARAMETER N8nApiUrl
    n8n API base URL. Default: https://ams.earneyit.com/api/v1

.PARAMETER N8nApiKey
    n8n API key. Required.

.PARAMETER DattoApiUrl
    Datto RMM API base URL.

.PARAMETER DattoApiKey
    Datto RMM API key. Required.

.PARAMETER DattoApiSecretKey
    Datto RMM API secret. Required.

.PARAMETER SiteUid
    Filter to a single Datto site UID. Otherwise processes all sites that have
    a row in the n8n 'Datto RMM Sites' data table.

.PARAMETER SecretsDataTableId
    n8n data-table ID holding the secrets. Default: zH9lcR7jDoTIaZoC

.PARAMETER SitesDataTableId
    n8n data-table ID mapping Datto siteUid -> Autotask companyID. Default
    matches the existing 'Datto RMM Sites' table.

.PARAMETER Rotate
    Generate a fresh secret even if one already exists in the data table.

.PARAMETER WhatIf
    Print planned actions without making any change.

.NOTES
    Requires PowerShell 7+ (uses ConvertFrom-Json -AsHashtable).
    Author: Earney IT
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$N8nApiUrl    = "https://ams.earneyit.com/api/v1",
    [Parameter(Mandatory)][string]$N8nApiKey,

    [string]$DattoApiUrl  = "https://concord-api.centrastage.net",
    [Parameter(Mandatory)][string]$DattoApiKey,
    [Parameter(Mandatory)][string]$DattoApiSecretKey,

    [string]$SiteUid,
    [string]$SecretsDataTableId = "zH9lcR7jDoTIaZoC",
    [string]$SitesDataTableId   = "Qb6jnqW6pQhHSzOD",
    [switch]$Rotate
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function New-Secret {
    # NIST IA-5(1) / SOC2 CC6.1 require cryptographic-strength authenticator material.
    # Get-Random is a Mersenne Twister seeded from a 32-bit PID/time mix and is documented
    # as unsuitable for cryptography. Use the OS CSPRNG instead.
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return ($bytes | ForEach-Object { '{0:x2}' -f $_ }) -join ''
}

function Invoke-N8n {
    param([string]$Method = 'GET', [string]$Path, $Body)
    $hdr = @{ 'X-N8N-API-KEY' = $N8nApiKey; 'Accept' = 'application/json' }
    $params = @{ Method = $Method; Uri = "$N8nApiUrl/$Path"; Headers = $hdr }
    if ($Body) {
        $params.ContentType = 'application/json'
        $params.Body = ($Body | ConvertTo-Json -Depth 10 -Compress)
    }
    return Invoke-RestMethod @params
}

function Get-DattoAuthHeader {
    # Datto RMM uses OAuth2 client credentials grant
    $tokenResp = Invoke-RestMethod -Method Post -Uri "$DattoApiUrl/auth/oauth/token" `
        -Headers @{ 'Authorization' = ('Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes('public-client:public'))) } `
        -Body @{ grant_type = 'password'; username = $DattoApiKey; password = $DattoApiSecretKey } `
        -ContentType 'application/x-www-form-urlencoded'
    return @{ 'Authorization' = "Bearer $($tokenResp.access_token)"; 'Accept' = 'application/json' }
}

function Set-DattoSiteVariable {
    param([string]$DattoSiteUid, [string]$VarName, [string]$VarValue, [hashtable]$Headers)
    $existing = $null
    try {
        $existing = Invoke-RestMethod -Method Get -Headers $Headers `
            -Uri "$DattoApiUrl/api/v2/site/$DattoSiteUid/variables"
    } catch { }
    $match = $existing.variables | Where-Object { $_.name -eq $VarName } | Select-Object -First 1

    $payload = @{ name = $VarName; value = $VarValue; masked = $true }
    if ($match) {
        if ($PSCmdlet.ShouldProcess("Datto site $DattoSiteUid", "update variable $VarName")) {
            Invoke-RestMethod -Method Put -Headers $Headers `
                -Uri "$DattoApiUrl/api/v2/variable/$($match.id)" `
                -ContentType 'application/json' `
                -Body ($payload | ConvertTo-Json -Compress) | Out-Null
        }
    } else {
        if ($PSCmdlet.ShouldProcess("Datto site $DattoSiteUid", "create variable $VarName")) {
            Invoke-RestMethod -Method Put -Headers $Headers `
                -Uri "$DattoApiUrl/api/v2/site/$DattoSiteUid/variable" `
                -ContentType 'application/json' `
                -Body ($payload | ConvertTo-Json -Compress) | Out-Null
        }
    }
}

# ---- Main ----
Write-Host "Loading sites from n8n 'Datto RMM Sites' data table..."
$sitesResp = Invoke-N8n -Path "data-tables/$SitesDataTableId/rows"
$sites = $sitesResp.data
if ($SiteUid) {
    $sites = $sites | Where-Object { $_.sites_uid -eq $SiteUid }
}
if (-not $sites) {
    Write-Host "No matching sites." -ForegroundColor Yellow
    exit 0
}
Write-Host "Matched $($sites.Count) site(s)."

Write-Host "Loading existing secrets..."
$secretsResp = Invoke-N8n -Path "data-tables/$SecretsDataTableId/rows"
$secretsBySite = @{}
foreach ($row in $secretsResp.data) { $secretsBySite[$row.site_uid] = $row }

Write-Host "Authenticating to Datto RMM..."
$dattoHeaders = Get-DattoAuthHeader

foreach ($site in $sites) {
    $uid  = $site.sites_uid
    $name = $site.sites_name
    Write-Host "`n=== $name ($uid) ==="

    $existingRow = $secretsBySite[$uid]
    $secret = if ($existingRow -and -not $Rotate) { $existingRow.webhook_secret } else { New-Secret }

    if ($existingRow -and -not $Rotate) {
        Write-Host "  Using existing secret (length=$($secret.Length))"
    } else {
        Write-Host "  Generated new secret (length=$($secret.Length))"
        $body = @{ data = @(@{ site_uid = $uid; webhook_secret = $secret }) }
        if ($existingRow) {
            if ($PSCmdlet.ShouldProcess("n8n datatable row $($existingRow.id)", "rotate secret")) {
                Invoke-N8n -Method 'PATCH' -Path "data-tables/$SecretsDataTableId/rows/$($existingRow.id)" -Body @{ data = @{ webhook_secret = $secret } } | Out-Null
            }
        } else {
            if ($PSCmdlet.ShouldProcess("n8n datatable", "insert secret for $uid")) {
                Invoke-N8n -Method 'POST' -Path "data-tables/$SecretsDataTableId/rows" -Body $body | Out-Null
            }
        }
    }

    try {
        Set-DattoSiteVariable -DattoSiteUid $uid -VarName 'EIT_WEBHOOK_SECRET' -VarValue $secret -Headers $dattoHeaders
        Write-Host "  Datto site variable EIT_WEBHOOK_SECRET set"
    } catch {
        Write-Host "  ! Failed to set Datto site variable: $_" -ForegroundColor Red
    }
}

Write-Host "`nProvisioning complete."
