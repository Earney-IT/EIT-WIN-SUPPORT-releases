@echo off
REM One-click installer for Earney IT Support App.
REM Self-elevates to admin and runs InstallSupportAgent.ps1 silently.

setlocal
set "SCRIPT_DIR=%~dp0"

REM Check for admin; if not, re-launch elevated
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

echo Installing Earney IT Support App...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%InstallSupportAgent.ps1"
set "RC=%ERRORLEVEL%"

if %RC% NEQ 0 (
    echo.
    echo Installation FAILED with exit code %RC%.
    echo Check the Windows Event Log ^(Application -^> EarneyIT^) for details.
    pause
    exit /b %RC%
)

echo.
echo Installation complete.
timeout /t 3 >nul
exit /b 0
