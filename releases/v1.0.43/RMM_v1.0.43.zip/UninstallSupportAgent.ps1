﻿<#
.SYNOPSIS
    Uninstalls Earney IT Support App from the system.

.DESCRIPTION
    Stops the app, removes Program Files install, shortcuts, and registry
    entries. Safe to run even if the app is already partially removed.

.PARAMETER Silent
    Suppress console output. Errors still write to Event Log and return a
    non-zero exit code.

.NOTES
    Requires: Administrator privileges
    Author: Earney IT

    Exit Codes:
        0  - Success (uninstalled, or already absent)
        1  - Failure
#>

#Requires -RunAsAdministrator

[CmdletBinding()]
param([switch]$Silent)

$ErrorActionPreference = "SilentlyContinue"

$AppName    = "Earney IT Support"
$InstallDir = Join-Path $env:ProgramFiles "EarneyIT\Support"

function Say([string]$msg) { if (-not $Silent) { Write-Host $msg } }
function Write-EvtLog([string]$msg, [string]$lvl = "Information") {
    try {
        if (-not [System.Diagnostics.EventLog]::SourceExists("EarneyIT")) {
            New-EventLog -LogName Application -Source "EarneyIT" -ErrorAction SilentlyContinue
        }
        Write-EventLog -LogName Application -Source "EarneyIT" -EventId 1001 `
            -EntryType $lvl -Message $msg -ErrorAction SilentlyContinue
    } catch {}
}

Say "============================================"
Say "  Uninstalling $AppName"
Say "============================================"
Say ""
Write-EvtLog "Starting uninstall of $AppName"

try {
    # Stop running instances
    Say "Stopping running instances..."
    $processes = Get-Process -Name "EarneyITSupport" -ErrorAction SilentlyContinue
    if ($processes) {
        $processes | Stop-Process -Force
        Start-Sleep -Seconds 2
        Say "  Stopped $($processes.Count) process(es)"
    } else {
        Say "  No running instances found"
    }

    # Remove startup entry
    Say "Removing startup entry..."
    Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name $AppName -ErrorAction SilentlyContinue
    Say "  Done"

    # Remove Start Menu folder and shortcuts
    Say "Removing Start Menu shortcuts..."
    Remove-Item "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Earney IT" -Recurse -Force -ErrorAction SilentlyContinue
    Say "  Done"

    # Remove Desktop shortcut
    Say "Removing Desktop shortcut..."
    Remove-Item "$env:PUBLIC\Desktop\New Support Request.lnk" -Force -ErrorAction SilentlyContinue
    Say "  Done"

    # Remove uninstall registry entry
    Say "Removing Add/Remove Programs entry..."
    Remove-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EarneyITSupport" -Recurse -Force -ErrorAction SilentlyContinue
    Say "  Done"

    # Remove app registry settings
    Say "Removing app registry settings..."
    Remove-Item "HKLM:\SOFTWARE\EarneyIT\Support" -Recurse -Force -ErrorAction SilentlyContinue

    # Remove URL-protocol handler (eitsupport://) registered for toast actions
    Say "Removing URL protocol handler..."
    Remove-Item "HKLM:\SOFTWARE\Classes\eitsupport" -Recurse -Force -ErrorAction SilentlyContinue

    # Remove per-user sign-in identity (best-effort — only clears for the
    # uninstalling admin's profile; roaming-user profiles get cleared on
    # next login when the missing exe trips the IdentityStore.Load path).
    Remove-Item "HKCU:\Software\EarneyIT\Support\Identity" -Recurse -Force -ErrorAction SilentlyContinue

    # Clean up empty parent EarneyIT key
    $earneyItKey = Get-Item "HKLM:\SOFTWARE\EarneyIT" -ErrorAction SilentlyContinue
    if ($earneyItKey -and $earneyItKey.GetSubKeyNames().Count -eq 0) {
        Remove-Item "HKLM:\SOFTWARE\EarneyIT" -Force -ErrorAction SilentlyContinue
    }
    Say "  Done"

    # Remove installation directory
    Say "Removing installation directory..."
    if (Test-Path $InstallDir) {
        Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $InstallDir) {
            # Held open by something — delayed delete
            Start-Process -FilePath "cmd.exe" -ArgumentList "/c timeout /t 3 >nul & rd /s /q `"$InstallDir`"" -WindowStyle Hidden
            Say "  Scheduled for delayed removal"
        } else {
            Say "  Done"
        }

        # Clean empty parent
        $parentDir = Split-Path $InstallDir -Parent
        if ((Test-Path $parentDir) -and ((Get-ChildItem $parentDir -ErrorAction SilentlyContinue).Count -eq 0)) {
            Remove-Item $parentDir -Force -ErrorAction SilentlyContinue
        }
    } else {
        Say "  Not present (already removed)"
    }

    Say ""
    Say "============================================"
    Say "  $AppName has been uninstalled"
    Say "============================================"
    Write-EvtLog "Uninstall completed successfully"
    exit 0

} catch {
    Say "ERROR: $_"
    Write-EvtLog "Uninstall failed: $_" "Error"
    exit 1
}
