﻿<#
.SYNOPSIS
    RMM-deployable updater. Checks the GitHub releases for a newer version of
    the Earney IT Support App and installs it silently.

.DESCRIPTION
    Intended to be run from Datto RMM (or any RMM) on a schedule. Pulls the
    latest release zip from GitHub, extracts it to a temp folder, and runs
    InstallSupportAgent.ps1 -Silent -NoLaunch -Force.

    No-op if the installed version is already at the latest tag.

.PARAMETER GitHubToken
    Optional. Personal Access Token for GitHub API access. Not required when
    pulling from the public releases repo (the default). Only needed if you
    point -Repo at a private repo. Pass via RMM site variable or env var; if
    omitted, falls back to $env:EIT_GH_TOKEN.

.PARAMETER Repo
    GitHub repo in 'owner/name' form. Default: Earney-IT/EIT-WIN-SUPPORT-releases
    (public). The legacy private repo (Earney-IT/EIT-WIN-SUPPORT) also works
    but requires -GitHubToken.

.PARAMETER Silent
    Suppress console output.

.PARAMETER Force
    Reinstall even when the installed version equals the latest release.

.NOTES
    Requires: Administrator privileges.
    Author: Earney IT

    Exit Codes:
        0  - Success (updated or already up-to-date)
        1  - Generic failure
        2  - No release asset found (or missing SHA256SUMS)
        3  - Download failed
        4  - Install script failed
        5  - SHA256 integrity check failed
        6  - Archive failed path-safety check (ZIP slip)
#>

#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [string]$GitHubToken = $env:EIT_GH_TOKEN,
    [string]$Repo = "Earney-IT/EIT-WIN-SUPPORT-releases",
    [switch]$Silent,
    [switch]$Force
)

# Initialise to make the finally-block check well-defined even on early failure
$tempRoot = $null

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Say([string]$msg, [string]$lvl = "INFO") {
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $lvl, $msg
    if (-not $Silent) { Write-Host $line }
    try {
        if (-not [System.Diagnostics.EventLog]::SourceExists("EarneyIT")) {
            New-EventLog -LogName Application -Source "EarneyIT" -ErrorAction SilentlyContinue
        }
        $entryType = switch ($lvl) { "ERROR" { "Error" } "WARNING" { "Warning" } default { "Information" } }
        Write-EventLog -LogName Application -Source "EarneyIT" -EventId 1002 `
            -EntryType $entryType -Message $msg -ErrorAction SilentlyContinue
    } catch {}
}

function Get-InstalledVersion {
    $reg = "HKLM:\SOFTWARE\EarneyIT\Support"
    if (Test-Path $reg) {
        $v = (Get-ItemProperty -Path $reg -Name "Version" -ErrorAction SilentlyContinue).Version
        if ($v) { return $v }
    }
    $exe = Join-Path $env:ProgramFiles "EarneyIT\Support\EarneyITSupport.exe"
    if (Test-Path $exe) {
        return (Get-Item $exe).VersionInfo.FileVersion
    }
    return $null
}

function Compare-Versions([string]$a, [string]$b) {
    try { return ([System.Version]::new($a)).CompareTo([System.Version]::new($b)) }
    catch { return 0 }
}

# Path-traversal-safe replacement for Expand-Archive. Rejects entries whose
# resolved destination would escape $DestinationPath (ZIP slip / CVE-style bug
# in older Expand-Archive implementations).
function Expand-ZipSafe {
    param(
        [Parameter(Mandatory)][string]$ZipPath,
        [Parameter(Mandatory)][string]$DestinationPath
    )
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    [System.IO.Directory]::CreateDirectory($DestinationPath) | Out-Null
    $dest = [System.IO.Path]::GetFullPath($DestinationPath)
    $sep  = [System.IO.Path]::DirectorySeparatorChar
    if (-not $dest.EndsWith($sep)) { $dest += $sep }

    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        foreach ($entry in $archive.Entries) {
            if ($entry.FullName -match '\.\.' -or [System.IO.Path]::IsPathRooted($entry.FullName)) {
                throw "Refusing zip entry with disallowed path component: $($entry.FullName)"
            }
            $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($dest, $entry.FullName))
            if (-not $target.StartsWith($dest, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Zip entry escapes destination: $($entry.FullName)"
            }
            if ([string]::IsNullOrEmpty($entry.Name)) {
                [System.IO.Directory]::CreateDirectory($target) | Out-Null
                continue
            }
            $parent = [System.IO.Path]::GetDirectoryName($target)
            if ($parent) { [System.IO.Directory]::CreateDirectory($parent) | Out-Null }
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $true)
        }
    } finally {
        $archive.Dispose()
    }
}

try {
    Say "Checking $Repo for latest release..."

    $headers = @{ "User-Agent" = "EarneyITSupport-Updater"; "Accept" = "application/vnd.github.v3+json" }
    if ($GitHubToken) { $headers["Authorization"] = "token $GitHubToken" }

    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/releases/latest" -Headers $headers
    $latestTag = ($release.tag_name -replace '^v', '')
    Say "Latest release: v$latestTag"

    $installed = Get-InstalledVersion
    if ($installed) {
        Say "Installed version: $installed"
        if ((Compare-Versions $latestTag $installed) -le 0 -and -not $Force) {
            Say "Already up-to-date. Nothing to do."
            exit 0
        }
    } else {
        Say "No installation detected — performing fresh install."
    }

    # Find the RMM_v*.zip and SHA256SUMS assets
    $asset = $release.assets | Where-Object { $_.name -like 'RMM_*.zip' } | Select-Object -First 1
    if (-not $asset) {
        Say "No RMM_*.zip asset in release $($release.tag_name)" -lvl "ERROR"
        exit 2
    }
    $shaAsset = $release.assets | Where-Object { $_.name -eq 'SHA256SUMS' } | Select-Object -First 1
    if (-not $shaAsset) {
        Say "Release is missing SHA256SUMS asset; refusing to install unverified update" -lvl "ERROR"
        exit 2
    }

    $downloadUrl = $asset.browser_download_url
    Say "Downloading $($asset.name) ..."

    $tempRoot = Join-Path $env:TEMP "EarneyIT_Update_$([Guid]::NewGuid().ToString('N'))"
    $zipPath  = Join-Path $tempRoot $asset.name
    $shaPath  = Join-Path $tempRoot 'SHA256SUMS'
    $extract  = Join-Path $tempRoot "extracted"
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $extract  -Force | Out-Null

    try {
        $dlHeaders = @{ "User-Agent" = "EarneyITSupport-Updater"; "Accept" = "application/octet-stream" }
        if ($GitHubToken) { $dlHeaders["Authorization"] = "token $GitHubToken" }
        # Download SHA256SUMS first so we can verify the zip
        Invoke-WebRequest -Uri $shaAsset.browser_download_url -Headers $dlHeaders -OutFile $shaPath -UseBasicParsing
        Invoke-WebRequest -Uri $downloadUrl -Headers $dlHeaders -OutFile $zipPath -UseBasicParsing
    } catch {
        Say "Download failed: $_" -lvl "ERROR"
        exit 3
    }

    # Parse SHA256SUMS — lines of "<64-hex>  <filename>"
    $expected = $null
    foreach ($line in (Get-Content -LiteralPath $shaPath)) {
        $parts = $line.Trim() -split '\s+', 2
        if ($parts.Count -eq 2 -and $parts[1].Trim() -ieq $asset.name) {
            $expected = $parts[0].Trim().ToLowerInvariant()
            break
        }
    }
    if (-not $expected -or $expected.Length -ne 64) {
        Say "SHA256SUMS does not contain an entry for $($asset.name)" -lvl "ERROR"
        exit 5
    }

    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $zipPath).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        Say "SHA256 mismatch! expected=$expected actual=$actual" -lvl "ERROR"
        exit 5
    }
    Say "SHA256 verified ($actual)"

    Say "Extracting ..."
    try {
        Expand-ZipSafe -ZipPath $zipPath -DestinationPath $extract
    } catch {
        Say "Refusing to extract update zip: $_" -lvl "ERROR"
        exit 6
    }

    $installScript = Join-Path $extract "InstallSupportAgent.ps1"
    if (-not (Test-Path $installScript)) {
        Say "InstallSupportAgent.ps1 not present in release zip" -lvl "ERROR"
        exit 2
    }

    Say "Running silent install..."
    $args = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installScript, "-Silent", "-NoLaunch", "-Force")
    $proc = Start-Process -FilePath "powershell.exe" -ArgumentList $args -Wait -PassThru -WindowStyle Hidden
    if ($proc.ExitCode -ne 0) {
        Say "InstallSupportAgent.ps1 exited with code $($proc.ExitCode)" -lvl "ERROR"
        exit 4
    }

    Say "Update to v$latestTag complete."
    exit 0

} catch {
    Say "Update failed: $_" -lvl "ERROR"
    exit 1
} finally {
    try { if ($tempRoot -and (Test-Path $tempRoot)) { Remove-Item $tempRoot -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
}
