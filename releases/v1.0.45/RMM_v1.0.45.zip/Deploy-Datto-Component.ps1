<#
.SYNOPSIS
    Datto RMM component: install or update the Earney IT Support tray app.

.DESCRIPTION
    Paste this whole file into a Datto RMM PowerShell component. On every
    run it will:

      1. Detect the installed version (if any) by reading
         C:\Program Files\EarneyIT\Support\EarneyITSupport.exe's
         FileVersion.
      2. Query the public Earney-IT/EIT-WIN-SUPPORT-releases repo for
         either the latest tag or a pinned EIT_PIN_VERSION.
      3. Short-circuit with exit 0 if the local version is already
         current or newer (unless EIT_FORCE_REINSTALL=true).
      4. Download RMM_v<version>.zip + SHA256SUMS from the release.
      5. Verify SHA-256 BEFORE extracting. Refuse to install on
         mismatch or untrusted download host.
      6. Extract to %ProgramData%\EarneyIT\Stage\download-v<version>
         (an admin-only path; the security audit called out %TEMP%
         as user-writable in its TOCTOU finding).
      7. Invoke the bundled InstallSupportAgent.ps1 with -Silent
         (and -Force / -WebhookSecret as configured).
      8. Re-read the installed version and bail with a non-zero exit
         if it did not actually advance to the target.

    Idempotent. Re-running on a current machine is a fast no-op.

.NOTES
    Runtime context: Datto RMM components run as NT AUTHORITY\SYSTEM.
    No UAC, no interactive prompts.

    Site variables (passed into the script via the process environment):

        EIT_WEBHOOK_SECRET    REQUIRED for first install. Per-tenant
                              HMAC secret. The Datto site variable name
                              must be literally "EIT_WEBHOOK_SECRET".
                              On upgrades it is optional. The local
                              InstallSupportAgent.ps1 preserves any
                              existing HKLM secret if not passed.

        EIT_FORCE_REINSTALL   Optional. "true" / "1" / "yes" passes
                              -Force to InstallSupportAgent.ps1 even
                              if the local version is current.

        EIT_PIN_VERSION       Optional. Pin to a specific release tag
                              (no leading "v"). Example: "1.0.44".
                              Useful for staged rollouts and to
                              recover after a bad release.

    Exit codes:
        0  Success. Installed, updated, or already current.
        1  Generic failure (network, install error, etc.).
        2  InstallSupportAgent.ps1 exited non-zero, or post-install
           version did not advance to the target.
        3  Integrity / trust failure (SHA mismatch, unknown host,
           missing SHA256SUMS). Refused to install.

    Logs are written to %ProgramData%\EarneyIT\Stage\install-<ts>.log
    AND streamed to stdout so the Datto job log captures everything.
#>

[CmdletBinding()]
param()  # Datto passes everything via environment vars; no script params.

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ---- Configuration ----------------------------------------------------
$RepoOwner    = 'Earney-IT'
$RepoName     = 'EIT-WIN-SUPPORT-releases'
$ApiBase      = 'https://api.github.com'
# Trust allow-list for download URLs. Mirrors the in-app updater's
# IsTrustedReleaseUrl logic so a redirected/MITM release manifest
# cannot trick us into running an exe from an unrelated host.
$TrustedHosts = @(
    'https://github.com/Earney-IT/EIT-WIN-SUPPORT-releases/',
    'https://objects.githubusercontent.com/'
)

$StageRoot    = 'C:\ProgramData\EarneyIT\Stage'
$LogTimestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$LogPath      = Join-Path $StageRoot ("install-{0}.log" -f $LogTimestamp)
$InstalledExe = 'C:\Program Files\EarneyIT\Support\EarneyITSupport.exe'

# Force TLS 1.2+. Windows Server 2016 and some older Win10 SKUs default
# to TLS 1.0/1.1 in PowerShell, which GitHub rejects.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ---- Logging ----------------------------------------------------------
function Write-Log {
    param([Parameter(Mandatory)][string]$Message, [string]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts] [$Level] $Message"
    Write-Host $line
    try { Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue } catch {}
}

function Stop-Deploy {
    param([Parameter(Mandatory)][string]$Message, [int]$ExitCode = 1)
    Write-Log -Level 'ERROR' $Message
    Write-Log -Level 'INFO'  "Aborting with exit $ExitCode. Log saved to: $LogPath"
    exit $ExitCode
}

# ---- 0. Bootstrap directory + header ---------------------------------
try { New-Item -ItemType Directory -Force -Path $StageRoot | Out-Null } catch {}

# Tighten the ACL on the stage dir so the downloaded zip + extracted
# contents are not readable by every interactive user. Best-effort; if
# icacls fails the directory keeps its default ProgramData ACL which is
# admin-write but world-read.
try {
    & icacls $StageRoot /inheritance:r 2>$null | Out-Null
    & icacls $StageRoot /grant:r 'BUILTIN\Administrators:(OI)(CI)F' 'NT AUTHORITY\SYSTEM:(OI)(CI)F' 2>$null | Out-Null
} catch {}

Write-Log "=== Earney IT Support - Datto RMM deployment ==="
Write-Log "Host:           $env:COMPUTERNAME"
try {
    $osCaption = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption
    Write-Log "OS:             $osCaption"
} catch {}
Write-Log "Identity:       $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Write-Log "Log:            $LogPath"

# ---- 1. Read configuration from environment --------------------------
$webhookSecret  = $env:EIT_WEBHOOK_SECRET
$forceReinstall = ($env:EIT_FORCE_REINSTALL -match '^(?i)(true|1|yes|on)$')
$pinVersion     = $env:EIT_PIN_VERSION

if ([string]::IsNullOrWhiteSpace($webhookSecret)) {
    Write-Log -Level 'WARN' "EIT_WEBHOOK_SECRET is not set. First-time installs will fail to authenticate; upgrades will preserve any existing secret."
} else {
    Write-Log "Webhook secret: present (length=$($webhookSecret.Length))"
}
if ($forceReinstall) { Write-Log "Force reinstall: ENABLED (EIT_FORCE_REINSTALL=$env:EIT_FORCE_REINSTALL)" }
if ($pinVersion)     { Write-Log "Pinned version:  v$pinVersion" }

# ---- 2. Detect installed version -------------------------------------
function Get-InstalledVersion {
    if (-not (Test-Path $InstalledExe)) { return $null }
    try {
        $raw = (Get-Item $InstalledExe).VersionInfo.FileVersion
        if (-not $raw) { return $null }
        $v = [Version]$raw
        return ("{0}.{1}.{2}" -f $v.Major, $v.Minor, $v.Build)
    } catch { return $null }
}

$installedVersion = Get-InstalledVersion
if ($installedVersion) {
    Write-Log "Installed:      v$installedVersion"
} else {
    Write-Log "Installed:      (not installed)"
    if ([string]::IsNullOrWhiteSpace($webhookSecret)) {
        # Fresh install needs a secret to be useful. We could install
        # without one and rely on a later run to provision it, but
        # then the tray would loudly fail to sign anything until the
        # next Datto job. Bail with a clear message instead.
        Stop-Deploy "Fresh install requires EIT_WEBHOOK_SECRET. Set the site variable in Datto and re-run." 1
    }
}

# ---- 3. Resolve the target release -----------------------------------
function Invoke-Github {
    param([Parameter(Mandatory)][string]$Path)
    $headers = @{
        'User-Agent' = 'EarneyIT-RMM-Deployer'
        'Accept'     = 'application/vnd.github+json'
    }
    $url = "$ApiBase$Path"
    Write-Log "GET             $url"
    try {
        return Invoke-RestMethod -Uri $url -Headers $headers -TimeoutSec 30
    } catch {
        Stop-Deploy "GitHub API request failed: $($_.Exception.Message)"
    }
}

if ($pinVersion) {
    $release = Invoke-Github "/repos/$RepoOwner/$RepoName/releases/tags/v$pinVersion"
} else {
    $release = Invoke-Github "/repos/$RepoOwner/$RepoName/releases/latest"
}

if (-not $release -or -not $release.tag_name) {
    Stop-Deploy "Release response had no tag_name."
}
$targetTag = ($release.tag_name).TrimStart('v')
Write-Log "Target:         v$targetTag"

# ---- 4. Idempotency: skip if already current -------------------------
function Test-IsCurrentOrNewer {
    param([string]$Installed, [string]$Target)
    if (-not $Installed) { return $false }
    try {
        return ([Version]$Installed) -ge ([Version]$Target)
    } catch {
        return $false
    }
}

if ((-not $forceReinstall) -and (Test-IsCurrentOrNewer -Installed $installedVersion -Target $targetTag)) {
    Write-Log "Already current. Nothing to do."
    Write-Log "=== Done. Exit 0. ==="
    exit 0
}

# ---- 5. Pick out + validate asset URLs -------------------------------
if (-not $release.assets) { Stop-Deploy "Release v$targetTag has no assets." 3 }

$zipAsset  = $release.assets | Where-Object { $_.name -like 'RMM_*.zip' } | Select-Object -First 1
$sumsAsset = $release.assets | Where-Object { $_.name -eq 'SHA256SUMS' }  | Select-Object -First 1
if (-not $zipAsset)  { Stop-Deploy "Release v$targetTag has no RMM_*.zip asset." 3 }
if (-not $sumsAsset) { Stop-Deploy "Release v$targetTag has no SHA256SUMS asset; refusing to install an unverifiable build." 3 }

function Test-TrustedUrl {
    param([string]$Url)
    foreach ($prefix in $TrustedHosts) {
        if ($Url.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}
if (-not (Test-TrustedUrl $zipAsset.browser_download_url))  { Stop-Deploy "Untrusted zip URL: $($zipAsset.browser_download_url)"  3 }
if (-not (Test-TrustedUrl $sumsAsset.browser_download_url)) { Stop-Deploy "Untrusted SHA256SUMS URL: $($sumsAsset.browser_download_url)" 3 }

# ---- 6. Download into a per-version staging dir ----------------------
$dl       = Join-Path $StageRoot ("download-v{0}" -f $targetTag)
$zipPath  = Join-Path $dl $zipAsset.name
$sumsPath = Join-Path $dl 'SHA256SUMS'

if (Test-Path $dl) {
    Remove-Item -Path $dl -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Force -Path $dl | Out-Null

Write-Log "Downloading:    $($zipAsset.browser_download_url)"
try {
    Invoke-WebRequest -Uri $zipAsset.browser_download_url -OutFile $zipPath -UseBasicParsing -TimeoutSec 300
} catch { Stop-Deploy "Zip download failed: $($_.Exception.Message)" }

Write-Log "Downloading:    $($sumsAsset.browser_download_url)"
try {
    Invoke-WebRequest -Uri $sumsAsset.browser_download_url -OutFile $sumsPath -UseBasicParsing -TimeoutSec 60
} catch { Stop-Deploy "SHA256SUMS download failed: $($_.Exception.Message)" }

# ---- 7. SHA-256 verify -----------------------------------------------
$expectedHash = $null
foreach ($line in Get-Content $sumsPath) {
    # Format: "<64 hex>  <filename>"
    if ($line -match '^([0-9a-fA-F]{64})\s+(.+)$') {
        if ($matches[2].Trim() -eq $zipAsset.name) {
            $expectedHash = $matches[1].ToLowerInvariant()
            break
        }
    }
}
if (-not $expectedHash) {
    Stop-Deploy "SHA256SUMS does not list $($zipAsset.name)." 3
}
$actualHash = (Get-FileHash -Algorithm SHA256 -Path $zipPath).Hash.ToLowerInvariant()
if ($actualHash -ne $expectedHash) {
    Stop-Deploy "SHA-256 mismatch: expected=$expectedHash actual=$actualHash" 3
}
Write-Log "SHA-256 OK:     $actualHash"

# ---- 8. Extract + run the bundled installer --------------------------
$extracted = Join-Path $dl 'extracted'
if (Test-Path $extracted) {
    Remove-Item -Path $extracted -Recurse -Force -ErrorAction SilentlyContinue
}
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $extracted)
} catch { Stop-Deploy "Extraction failed: $($_.Exception.Message)" }

$installer = Join-Path $extracted 'InstallSupportAgent.ps1'
if (-not (Test-Path $installer)) {
    Stop-Deploy "Extracted package missing InstallSupportAgent.ps1; malformed release." 3
}

Write-Log "Invoking:       $installer"
$installerArgs = @(
    '-NoLogo','-NoProfile','-ExecutionPolicy','Bypass',
    '-File', $installer,
    '-Silent'
)
if ($forceReinstall) { $installerArgs += '-Force' }
if (-not [string]::IsNullOrWhiteSpace($webhookSecret)) {
    $installerArgs += @('-WebhookSecret', $webhookSecret)
}

# -PassThru gives us the process object so we can read ExitCode after
# -Wait. -NoNewWindow so output flows back to the Datto job log.
$proc = Start-Process -FilePath 'powershell.exe' `
    -ArgumentList $installerArgs `
    -Wait -PassThru -NoNewWindow
if ($proc.ExitCode -ne 0) {
    Stop-Deploy "InstallSupportAgent.ps1 exited with code $($proc.ExitCode)." 2
}

# ---- 9. Verify the install actually advanced --------------------------
$postVersion = Get-InstalledVersion
if (-not $postVersion) {
    Stop-Deploy "Post-install check: exe is missing from $InstalledExe." 2
}
if (-not (Test-IsCurrentOrNewer -Installed $postVersion -Target $targetTag)) {
    Stop-Deploy "Post-install version v$postVersion is older than target v$targetTag." 2
}
Write-Log "Installed OK:   v$postVersion"

# ---- 10. Cleanup -----------------------------------------------------
try {
    Remove-Item -Path $dl -Recurse -Force -ErrorAction SilentlyContinue
    Write-Log "Cleaned up:     $dl"
} catch {
    Write-Log -Level 'WARN' "Could not clean up $dl; leaving for next run to overwrite."
}

Write-Log "=== Done. Exit 0. ==="
exit 0
